# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   NAbraha, 05/08/2017, Added code to complete assignment 5
#   NAbraha, 05/30/2017, Organized code into functions and class
#  https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#


#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
objFile = open("Todo.txt", "r")

# strData = A row of text data from the file
strData = ""

# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}

# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []

# strMenu = A menu of user options

# strChoice = Capture the user option selections
strChoice = 0


# -- Processing --#

class ToDoListOrganizer(object):
    # Loads data from text file and returns python list called lstTable
    @staticmethod
    def DataLoad():
        # Step 1
        # When the program starts, load the any data you have
        # in a text file called ToDo.txt into a python Dictionary.
        for lineData in objFile:
            strData = lineData.strip().split(',')
            dicRow = {strData[0]: strData[1]}
            lstTable.append(dicRow)
        return lstTable

    # Step 2: Displays menu of choices to user
    @staticmethod
    def MenuOptions():
        strMenu = ("""
        ********************************      
    
        Please choose from Menu:
            1) Show current data
            2) Add a new item
            3) Remove an existing item
            4) Save Data and Exit
            """)
        return strMenu

    # Step 3: Display all todo items to user
    def DisplayData():
        list = []
        x = 1 #Initializing x as 1 , to use x as counter of tasks
        for strData in lstTable:
            for Task, Priority in strData.items():
                line = "#" + str(x) + ": " + str(Task) + ", priority level of " + str(Priority)
                list.append(line)
                x = x + 1
        return list

    # Step 4 - Add or delete a new item to the list/Table
    @staticmethod
    def AddOrRemoveTasks(strChoice, Task, Priority):
        if strChoice == '2':
            dicRow = {Task: Priority}
            lstTable.append(dicRow)
            return lstTable
        elif strChoice == '3':
            for strData in lstTable:
                notFound = True
                if Task in strData.keys():
                    lstTable.remove(strData)
                    notFound = False
            return notFound

    # Step 6 - Save tasks to the ToDo.txt file and Exits
    @staticmethod
    def SaveAndExit():
        objFile = open("ToDo.txt", "w")
        for strData in lstTable:
            for Task, Value in strData.items():
                task = str(Task)
                value = str(Value)
                objFile.write(task + "," + value + "\n")
        objFile.close()


# -- Input/Output --#

# Step 1
ToDoListOrganizer.DataLoad()

print("We will be managing a list of your To Do items!")
while(True):
    # Step 2: User can see Menu and chooses option
    print(ToDoListOrganizer.MenuOptions())
    strChoice = str(input("What would you like to do? [1 to 4] - "))
    print()

    # Step 3: Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Your current tasks and priority levels:" + "\n")
        print("\n".join(ToDoListOrganizer.DisplayData()))

    # Step 4 and 5: Add or Remove Tasks
    if (strChoice.strip() == '2'):
        Task = input("What is your task? ")
        Priority = input("What is the priority level for this task? ")
        ToDoListOrganizer.AddOrRemoveTasks(strChoice, Task, Priority)
        print(Task, "with a priority level of", Priority, "has now been added to your to do list.")

    # Step 5 - Remove a new item to the list/Table
    if (strChoice == '3'):
        Task = input("Which item would you like to remove? ")
        Priority = ""
        if ToDoListOrganizer.AddOrRemoveTasks(strChoice, Task, Priority):
            print("Task was not found in your To Do list.")
        else:
            print("You have deleted", Task)

    # Step 6 - Save tasks to text file and exit program
    if (strChoice == '4'):
        ToDoListOrganizer.SaveAndExit()
        print("Your To Do List has been updated. Thank you! Goodbye!")
        break