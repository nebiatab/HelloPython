#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Nebiat Abraha, 05/08/2017, Added code to complete assignment 5
#  https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selections

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------


strData = ""
dicRow = {}
lstTable = []

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
objFile = open("Todo.txt", "r")
for lineData in objFile:
    strData = lineData.strip().split(',')
    dicRow = {strData[0]:strData[1]}
    lstTable.append(dicRow)

print("We will be managing a list of your To Do items!")
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
********************************      
  
Please choose from Menu:
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("What would you like to do? [1 to 4] - "))
    print()

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Your current tasks and priority levels:" + "\n")
        x = 1 #Initializing x as 1 , to use x as counter of tasks
        for strData in lstTable:
            for Task, Priority in strData.items():
                print("#",x, ":", Task, ", priority level of", Priority)
                x = x + 1
        continue

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        Task = input("What is your task? ")
        Priority = input("What is the priority level for this task? ")
        dicRow = {Task: Priority}
        lstTable.append(dicRow)
        print(Task, "with a priority level of", Priority, "has now been added to your to do list.")
        continue

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        delTask = input("Which item would you like to remove? ")
        notFound = True
        for strData in lstTable:
            if delTask in strData.keys():
                lstTable.remove(strData)
                print("You have deleted", delTask)
                notFound = False
        if notFound == True:
            print("Task was not found in your To Do list.")
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFile = open("ToDo.txt", "w")
        for strData in lstTable:
            for Task, Value in strData.items():
                task = str(Task)
                value = str(Value)
                objFile.write(task + "," + value + "\n")
        objFile.close()
        continue

    elif (strChoice == '5'):
        print("Thank you! Goodbye!")
        break #and Exit the program

